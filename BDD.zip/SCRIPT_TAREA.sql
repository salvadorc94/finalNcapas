--CREACION DE TABLAS Y LLAVE FORANEA---
CREATE TABLE usuario(
	idUsuario SERIAL primary key,
	usuario varchar(150),
	clave varchar(150)
);

CREATE TABLE sucursal(
	codigo SERIAL primary key,
	nombre varchar(150),
	ubicacion varchar(300),
	horarioApertura varchar(100),
	horarioCierre varchar(100),
	nMesas int,
	nomGerente varchar(150)
);

CREATE TABLE empleado(
	codigo SERIAL primary key,
	nombre varchar(150),
	edad int,
	genero varchar(50),
	estado boolean,
	sucursal int
);

ALTER TABLE empleado ADD CONSTRAINT fk_sucursal FOREIGN KEY (sucursal) REFERENCES sucursal (codigo);

--POBLACION DE BASE DE DATOS---
insert into usuario (idUsuario, usuario, clave) values (1, 'eleuchars0', 'pass');
insert into usuario (idUsuario, usuario, clave) values (2, 'mshireff1', 'pass');
insert into usuario (idUsuario, usuario, clave) values (3, 'jcolumbell2', '12345');
insert into usuario (idUsuario, usuario, clave) values (4, 'cstollenbeck3', 'asd');
insert into usuario (idUsuario, usuario, clave) values (5, 'acrannach4', 'pass');
insert into usuario (idUsuario, usuario, clave) values (6, 'salvador', 'root');

insert into sucursal (codigo, nombre, ubicacion, horarioapertura, horariocierre, nmesas, nomgerente) values (1, 'mtrendle0', '86 Northview Circle', '2:35 AM', '1:51 AM', 35, 'Maitilde Trendle');
insert into sucursal (codigo, nombre, ubicacion, horarioapertura, horariocierre, nmesas, nomgerente) values (2, 'gcocklin1', '93250 Melody Parkway', '12:31 AM', '4:20 PM', 60, 'Geneva Cocklin');
insert into sucursal (codigo, nombre, ubicacion, horarioapertura, horariocierre, nmesas, nomgerente) values (3, 'jcressar2', '786 Goodland Alley', '2:00 AM', '10:48 AM', 29, 'Jewell Cressar');
insert into sucursal (codigo, nombre, ubicacion, horarioapertura, horariocierre, nmesas, nomgerente) values (4, 'oruslen3', '186 Carpenter Avenue', '12:03 AM', '12:16 PM', 31, 'Odey Ruslen');
insert into sucursal (codigo, nombre, ubicacion, horarioapertura, horariocierre, nmesas, nomgerente) values (5, 'farmit4', '1 Glacier Hill Avenue', '4:55 AM', '5:47 AM', 33, 'Flossie Armit');

insert into empleado (codigo, nombre, edad, genero, estado, sucursal) values (1, 'Celka Huerta', 42, 'Femenino', false, 4);
insert into empleado (codigo, nombre, edad, genero, estado, sucursal) values (2, 'Nevile Spurgin', 48, 'Masculino', true, 5);
insert into empleado (codigo, nombre, edad, genero, estado, sucursal) values (3, 'Tilda Cotsford', 51, 'Masculino', true, 1);
insert into empleado (codigo, nombre, edad, genero, estado, sucursal) values (4, 'Cassi Sommerling', 42, 'Masculino', false, 4);
insert into empleado (codigo, nombre, edad, genero, estado, sucursal) values (5, 'Hollis Thickens', 47, 'Masculino', false, 5);